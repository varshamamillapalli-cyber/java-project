package com.klu.apas.report;

import java.util.List;
import com.klu.apas.model.Student;

public interface ReportWriter {
    void writeReport(List<Student> students, String fileName) throws Exception;
}

