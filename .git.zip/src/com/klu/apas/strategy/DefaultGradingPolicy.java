package com.klu.apas.strategy;

public class DefaultGradingPolicy implements GradingPolicy {
    public String computeGrade(int total) {
        if (total >= 180) return "A+";
        if (total >= 160) return "A";
        if (total >= 140) return "B";
        if (total >= 120) return "C";
        return "D";
    }
}

