package com.klu.apas.io;

import java.io.*;
import java.util.*;

public class FileUtil implements CsvOperations {

    public List<String> read(String fileName) throws Exception {
        List<String> lines = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String line;
        while ((line = br.readLine()) != null) {
            lines.add(line);
        }
        br.close();
        return lines;
    }

    public void write(String fileName, String data) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
        bw.write(data);
        bw.close();
    }
}

