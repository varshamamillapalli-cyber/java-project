package com.klu.apas.service;

import java.util.List;
import com.klu.apas.model.Student;

public interface AnalyticsService {
    int calculateTotal(Student s);
    double calculateMean(List<Integer> marks);
    double calculateMedian(List<Integer> marks);
    double calculateStdDev(List<Integer> marks);
    String assignGrade(int total);
}

