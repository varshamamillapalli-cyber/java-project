package com.klu.apas.util;

import java.util.*;

public class MathUtil {

    public static double calculateMean(List<Integer> nums) {
        double sum = 0;
        for (int n : nums) sum += n;
        return sum / nums.size();
    }

    public static double calculateMedian(List<Integer> nums) {
        Collections.sort(nums);
        int n = nums.size();
        if (n % 2 == 0)
            return (nums.get(n/2 - 1) + nums.get(n/2)) / 2.0;
        return nums.get(n/2);
    }

    public static double calculateStdDev(List<Integer> nums) {
        double mean = calculateMean(nums);
        double sum = 0;
        for (int n : nums)
            sum += Math.pow(n - mean, 2);
        return Math.sqrt(sum / nums.size());
    }
}
