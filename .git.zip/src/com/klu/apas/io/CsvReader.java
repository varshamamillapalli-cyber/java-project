package com.klu.apas.io;

import java.util.List;

public abstract class CsvReader {

    public List<?> readCsv(String fileName) throws Exception {
        List<String> lines = readLines(fileName);
        return parse(lines);
    }

    protected abstract List<?> parse(List<String> lines) throws Exception;

    protected List<String> readLines(String fileName) throws Exception {
        FileUtil util = new FileUtil();
        return util.read(fileName);
    }
}

