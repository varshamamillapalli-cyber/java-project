package com.klu.apas.service;

import java.util.ArrayList;
import java.util.List;

import com.klu.apas.model.Student;
import com.klu.apas.strategy.GradingPolicy;
import com.klu.apas.strategy.DefaultGradingPolicy;
import com.klu.apas.util.MathUtil;

public class BasicAnalyticsService implements AnalyticsService {

    private GradingPolicy gradingPolicy = new DefaultGradingPolicy();

    public int calculateTotal(Student s) {
        int sum = 0;
        for (int m : s.getSubjectMarks().values()) {
            sum += m;
        }
        s.setTotalMarks(sum);
        return sum;
    }

    public double calculateMean(List<Integer> marks) {
        return MathUtil.calculateMean(marks);
    }

    public double calculateMedian(List<Integer> marks) {
        return MathUtil.calculateMedian(marks);
    }

    public double calculateStdDev(List<Integer> marks) {
        return MathUtil.calculateStdDev(marks);
    }

    public String assignGrade(int total) {
        return gradingPolicy.computeGrade(total);
    }
}

