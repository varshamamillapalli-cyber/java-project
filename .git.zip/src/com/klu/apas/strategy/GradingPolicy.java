package com.klu.apas.strategy;

public interface GradingPolicy {
    String computeGrade(int total);
}

