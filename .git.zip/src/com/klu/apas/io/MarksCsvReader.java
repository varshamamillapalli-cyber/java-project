package com.klu.apas.io;

import java.util.ArrayList;
import java.util.List;

import com.klu.apas.model.Mark;

public class MarksCsvReader extends CsvReader {

    protected List<Mark> parse(List<String> lines) {
        List<Mark> marks = new ArrayList<>();

        for (int i = 1; i < lines.size(); i++) {
            String[] data = lines.get(i).split(",");
            marks.add(new Mark(
                    Integer.parseInt(data[0]),
                    data[1],
                    Integer.parseInt(data[2])
            ));
        }
        return marks;
    }
}

