package main;

import java.util.*;

import com.klu.apas.io.*;
import com.klu.apas.model.*;
import com.klu.apas.report.*;
import com.klu.apas.service.*;

public class MainApp {

    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in);
        List<Student> students = new ArrayList<>();
        List<Mark> marks = new ArrayList<>();

        AnalyticsService service = new BasicAnalyticsService();

        while (true) {
            System.out.println("========= ACADEMIC PERFORMANCE ANALYTICS SYSTEM =========");
            System.out.println("1. Load Students CSV");
            System.out.println("2. Load Marks CSV");
            System.out.println("3. Perform Analytics");
            System.out.println("4. Generate Report CSV");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    students = (List<Student>) new StudentCsvReader()
                            .readCsv("students.csv");
                    System.out.println("Students Loaded");
                    break;

                case 2:
                    marks = (List<Mark>) new MarksCsvReader()
                            .readCsv("marks.csv");
                    for (Mark m : marks) {
                        for (Student s : students) {
                            if (s.getRoll() == m.getRoll())
                                s.addMark(m.getSubject(), m.getMarks());
                        }
                    }
                    System.out.println("Marks Loaded");
                    break;

                case 3:
                    for (Student s : students) {
                        int total = service.calculateTotal(s);
                        s.setGrade(service.assignGrade(total));
                        s.displayStudentInfo();
                    }
                    break;

                case 4:
                    ReportWriter writer = ReportWriterFactory.getWriter("csv");
                    writer.writeReport(students, "grades.csv");
                    System.out.println("Report Generated");
                    break;
                    

                case 5:
                    System.out.println("Thanku");
            }
        }
    }
}
