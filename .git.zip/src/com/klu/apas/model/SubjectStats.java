package com.klu.apas.model;

import java.util.List;
import com.klu.apas.util.MathUtil;

public class SubjectStats {
    private double mean;
    private double median;
    private double stdDev;
    private List<Integer> marks;

    public SubjectStats(List<Integer> marks) {
        this.marks = marks;
        this.mean = MathUtil.calculateMean(marks);
        this.median = MathUtil.calculateMedian(marks);
        this.stdDev = MathUtil.calculateStdDev(marks);
    }

    public double getMean() { return mean; }
    public double getMedian() { return median; }
    public double getStdDev() { return stdDev; }
}

