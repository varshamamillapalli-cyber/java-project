package com.klu.apas.model;

public class Mark {
    private int roll;
    private String subject;
    private int marks;

    public Mark(int roll, String subject, int marks) {
        this.roll = roll;
        this.subject = subject;
        this.marks = marks;
    }

    public int getRoll() {
        return roll;
    }

    public String getSubject() {
        return subject;
    }

    public int getMarks() {
        return marks;
    }
}

