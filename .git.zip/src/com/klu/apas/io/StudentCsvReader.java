package com.klu.apas.io;

import java.util.ArrayList;
import java.util.List;

import com.klu.apas.model.Student;

public class StudentCsvReader extends CsvReader {

    protected List<Student> parse(List<String> lines) {
        List<Student> students = new ArrayList<>();

        for (int i = 1; i < lines.size(); i++) {
            String[] data = lines.get(i).split(",");
            students.add(new Student(
                    Integer.parseInt(data[0]),
                    data[1],
                    data[2]
            ));
        }
        return students;
    }
}

