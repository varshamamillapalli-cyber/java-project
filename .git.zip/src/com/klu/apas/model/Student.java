package com.klu.apas.model;

import java.util.HashMap;
import java.util.Map;

public class Student extends Person {
    private String className;
    private Map<String, Integer> subjectMarks = new HashMap<>();
    private int totalMarks;
    private String grade;

    public Student() {}

    public Student(int roll, String name, String className) {
        super(roll, name);
        this.className = className;
    }

    public void addMark(String subject, int marks) {
        subjectMarks.put(subject, marks);
    }

    public Map<String, Integer> getSubjectMarks() {
        return subjectMarks;
    }

    public int getTotalMarks() {
        return totalMarks;
    }

    public void setTotalMarks(int totalMarks) {
        this.totalMarks = totalMarks;
    }

    public String getClassName() {
        return className;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getGrade() {
        return grade;
    }

    public void displayStudentInfo() {
        System.out.println(roll + " " + name + " " + className +
                " Total: " + totalMarks + " Grade: " + grade);
    }
}

