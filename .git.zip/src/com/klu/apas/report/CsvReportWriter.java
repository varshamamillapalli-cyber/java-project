package com.klu.apas.report;

import java.util.List;

import com.klu.apas.model.Student;
import com.klu.apas.io.FileUtil;

public class CsvReportWriter implements ReportWriter {

    public void writeReport(List<Student> students, String fileName) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("Roll,Name,Class,Total,Grade\n");

        for (Student s : students) {
            sb.append(s.getRoll()).append(",")
              .append(s.getName()).append(",")
              .append(s.getClassName()).append(",")
              .append(s.getTotalMarks()).append(",")
              .append(s.getGrade()).append("\n");
        }

        new FileUtil().write(fileName, sb.toString());
    }
}

